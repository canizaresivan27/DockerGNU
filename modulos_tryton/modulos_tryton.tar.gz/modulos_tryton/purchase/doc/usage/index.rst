*****
Usage
*****

Settings, information and tasks relating to purchases can be found under the
[:menuselection:`Purchase`] main menu item.

.. toctree::
   :maxdepth: 1

   prepurchase
   process
   returns
