GNU Health Paper Archive module
-------------------------------

Funtionality to locate the patient medical record on paper on each institution.

It also provides information about the status of the document, scanning and attaching it to the electronic record.
