List of modules needed (will change):

- User (ships with tryton)
- Party (ships with tryton)
- Language (ships with tryton)
- GNU Health base
- GNU Health Lab
- GNU Health Nursing
- GNU Health ICU
- GNU Health Inpatient
- GNU Health Surgery
- GNU Health ICD10
- GNU Health ICD10pcs
