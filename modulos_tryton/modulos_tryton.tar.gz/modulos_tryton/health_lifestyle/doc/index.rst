GNU HEALTH - Lifestyle Module
#############################

Gathers information about the habits and sexuality of the patient

- Eating habits and diets
- Sleep patterns
- Recreational drugs database from NIDA
- Henningfield drug ratings
- Drug / alcohol addictions
- Physical activity (workout / excercise )
- Sexuality and sexual behaviour
- Driving, Home and Child safety
