GNU HEALTH : Surgery Module
###########################

Basic Surgery Module for GNU Health

If you want to include standard codings for procedures, please install
corresponding module, like ICD10-PCS

