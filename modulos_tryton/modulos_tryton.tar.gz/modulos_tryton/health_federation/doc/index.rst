GNU Health Federation Interface
--------------------------------

Module that will allow connecting and exchange information with the GNU Health Federation 
