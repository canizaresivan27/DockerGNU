GNU Health Calendar for WebDAV3

===============================

The package is the continuation of the CalDAV functionality
for the discontinued Tryton package.


It has been ported to Python 3 and GNU Health.

