*****
Usage
*****

This module provides a list of `Countries <model-country.country>` and other
reference data which is normally managed using the
:doc:`provided scripts <setup>`.

.. tip::

   From a country you can :guilabel:`Open related records` and select
   :guilabel:`Postal Codes` to find a list of all the `Postal Codes
   <model-country.postal_code>` for that country.
