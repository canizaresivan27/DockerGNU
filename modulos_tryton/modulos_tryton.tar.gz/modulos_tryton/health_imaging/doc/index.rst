GNU Health Imaging Module
#########################

- Imaging types and tests.
- Imaging test requests and results.
