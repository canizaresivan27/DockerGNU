############
Party Module
############

The *Party Module* is used to store and manage information about people,
businesses, organisations, and associations.
It allows you to save information such as contact details, addresses,
identifiers and the language used by each of these different entities.

.. toctree::
   :maxdepth: 2

   usage
   design
