GNU Health Basic Epidemics contact tracing
------------------------------------------

It allows to trace and follow-up the contacts that a person suspected of a infectious
disease.



